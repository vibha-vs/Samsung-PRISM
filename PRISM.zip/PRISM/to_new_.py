from flask import Flask, request, jsonify
import werkzeug
import cv2
import os
import json

def cloud_points_generator(contours,height):
    
    final_contour_list = []
    for contour in contours:   
        contour_points = []
        for point in contour:
            print(point[0][0])
            new_base_point = [point[0][0],point[0][1],0]
            print(new_base_point)
            
            new_top_point = [point[0][0],point[0][1],height]
            print(new_top_point)
            
            contour_points.append(new_base_point)
            contour_points.append(new_top_point)
        
        
        final_contour_list.append(contour_points)
    return final_contour_list
            
def detect_walls(im_link,height):

    im = cv2.imread(im_link)
    img = im.copy()
    imgray = cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
    ret,thresh = cv2.threshold(imgray,10,255,0)
    contours, hierarchy = cv2.findContours(thresh,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

    new_contours = []
    for contour in contours:
        
        area = cv2.contourArea(contour)
        if area > 50:
            new_contours.append(contour)
            
    ff = cloud_points_generator(new_contours, height)
    
    for item in ff:
        for point in item:
            for i in range(len(point)):
                point[i] = int(point[i])
    
    my_json = json.dumps(ff)
    json_str = json.dumps(my_json)

    with open('data.json', 'w') as f:
        json.dump(json.loads(json_str), f, indent=4)
    #print(json.dumps(ff))
    return ff











a = detect_walls('houseplan2.png',5)
    