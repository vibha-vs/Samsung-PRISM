# import http.server
# #import SimpleHTTPServer
# import json
# # I'm using SimpleHTTPServer because it already has most of the functionality
# # and you can add files to be served at will.

# INDEX_HTML = """
# <html>
# <head>
# <script type="text/javascript" src="/data.js"></script>
# <script type="text/javascript">
# function showStuff() {
#     document.getElementById("fldcnt").innerText = data['foldercount']
# }
# </script>
# </head>
# <body onload="showStuff()">Folder Count:<span id="fldcnt"></span></body></html>
# """


# class MyHTTPRequestHandler(http.server.SimpleHTTPRequestHandler, object):
#     def do_GET(self):
#         if self.path == '':
#             data = {"foldercount": 15}
#             self.wfile.write('var data=' + json.dumps(data))
#         elif self.path == '/':
#             self.wfile.write(INDEX_HTML.encode())
#         else:
#             super(MyHTTPRequestHandler, self).do_GET()


# def main():
#     server_address = ('', 8000)
#     httpd = http.server.HTTPServer(server_address, MyHTTPRequestHandler)
#     httpd.serve_forever()


# if __name__ == "__main__":
#     main()