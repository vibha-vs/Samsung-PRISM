// import './style.css'
import * as THREE from 'https://unpkg.com/three@0.126.1/build/three.module.js'
import { OrbitControls } from 'https://unpkg.com/three@0.126.1/examples/jsm/controls/OrbitControls.js';

/* ***** */
// const scene = new THREE.Scene();
// const camera = new THREE.PerspectiveCamera(
//   75,
//   window.innerWidth / window.innerHeight,
//   0.1,
//   1000
// );

// const renderer = new THREE.WebGLRenderer();
// renderer.setSize(window.innerWidth, window.innerHeight);
// document.body.appendChild(renderer.domElement);

// fetch("data.json")
//   .then((response) => response.json())
//   .then((jsonData) => {
//     // const geometry = new THREE.BoxGeometry(
//     //   jsonData.width,
//     //   jsonData.height,
//     //   jsonData.depth
//     // ); 

//     const material = new THREE.MeshBasicMaterial({ color: 0xff0000 });
//     const mesh = new THREE.Mesh(geometry, material);

//     scene.add(mesh);
//     scene.background = new THREE.Color(0xffffff);

//     camera.position.z = 5;

//     renderer.render(scene, camera);
//   });
/******* */

//start
const jsonUrl = 'data2.json';
const response = await fetch(jsonUrl);
const json = await response.json();

// console.log('response:', response);
// console.log('json:', json);

const input = json

const output = {
  "contours": JSON.parse(input).map((arr) => {
    return arr.map((coords) => {
      return {
        "x": coords[0],
        "y": coords[1],
        "z": coords[2]
      };
    });
  })
};

console.log(JSON.stringify(output));

const scene = new THREE.Scene();
const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);
renderer.setPixelRatio(window.devicePixelRatio);
const camera = new THREE.PerspectiveCamera(
    75,
    window.innerWidth / window.innerHeight,
    1,
    10000
);
camera.position.set(500, 500, 500);
const controls = new OrbitControls(camera, renderer.domElement);
controls.update();
const light = new THREE.AmbientLight(0xffaaff);
light.position.set(10, 10, 10);
scene.add(light);

const geometry = new THREE.BufferGeometry();
const vertices = [];

//console.log(Array.isArray(json.contours))
//const contours = Array.isArray(json.contours) ? json.contours : Object.values(json.contours);
// if (Array.isArray(json.contours)) {
  for (const contour of output.contours) {
    console.log(output.contours)
    // Calculate the number of vertices in this contour
    const numVertices = contour.length;

    // Add each vertex to the vertices array
    for (let i = 0; i < numVertices; i++) {
      const point = contour[i];
      vertices.push(point.x, point.y, 0);
      // geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
      // const dotMaterial = new THREE.PointsMaterial({ size: 10, color: 0xff0000 });
      // const dot = new THREE.Points(geometry, dotMaterial);
      // scene.add(dot);
      // renderer.render(scene, camera);
    }
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
    const material = new THREE.LineBasicMaterial({ color: 0xff0000 });
    const line = new THREE.Line(geometry, material);
    scene.add(line);
    renderer.render(scene, camera);
    // Close the contour
    const firstPoint = contour[0];
    vertices.push(firstPoint.x, firstPoint.y, firstPoint.z);
   }
//  }




// geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
// console.log('vertices:', vertices);
// console.log('geometry:', geometry);
// const material = new THREE.LineBasicMaterial({ color: 0xff0000 });
// const line = new THREE.Line(geometry, material);

/**** */
// // Parse the JSON data
// const contours = output.contours;

// // Create an array to hold the 3D meshes
// const meshes = [];

// // Loop over each contour and create a 3D mesh for it
// for (let i = 0; i < contours.length; i++) {
//   const contour = contours[i];

//   const shape = new THREE.Shape();
//   shape.moveTo(contour[0].x, contour[0].y);

//   for (let j = 1; j < contour.length; j++) {
//     shape.lineTo(contour[j].x, contour[j].y);
//   }

//   const geometry = new THREE.ExtrudeGeometry(shape, {
//     depth: 10,
//     bevelEnabled: false
//   });

//   const mesh = new THREE.Mesh(geometry, new THREE.MeshPhongMaterial({ color: 0xffffff }));
//   meshes.push(mesh);
// }

// // Add the array of meshes to the scene
// for (let i = 0; i < meshes.length; i++) {
//   scene.add(meshes[i]);
// }

// scene.add(line);
// renderer.render(scene, camera);


//for each point
    // const contours = output.contours;
    // // create a new geometry and material for each contour
    // for (let i = 0; i < contours.length; i++) {
    //   const points = contours[i].map(coord => new THREE.Vector3(coord.x, coord.y, coord.z));
    //   const geometry = new THREE.BufferGeometry().setFromPoints(points);
    //   const material = new THREE.PointsMaterial({ color: 0xffffff, size: 5 });
    //   const pointsObject = new THREE.Points(geometry, material);
    //   scene.add(pointsObject);
    //   renderer.render(scene, camera);
    // }


//for each line
// create scene and camera

  // create material
  // var material = new THREE.MeshBasicMaterial( { color: 0xffffff, side: THREE.DoubleSide } );
  // const meshes = [];
  // // iterate through each contour
  // for (var i = 0; i < output.contours.length; i++) {
  //   var contour = output.contours[i];

  //   // create shape and add points to it
  //   var shape = new THREE.Shape();
  //   shape.moveTo(contour[0].x, contour[0].y);
  //   for (var j = 1; j < contour.length; j++) {
  //     shape.lineTo(contour[j].x, contour[j].y);
  //   }
  //   shape.lineTo(contour[0].x, contour[0].y); // close the shape
  //   const geometry = new THREE.ExtrudeGeometry(shape, {
  //         depth: 100,
  //         bevelEnabled: false
  //       });
  //   // create mesh and add it to the scene
  //   // var geometry = new THREE.ShapeGeometry( shape );
  //  var mesh = new THREE.Mesh( geometry, material );
  // //  const mesh = new THREE.Mesh(geometry, new THREE.MeshPhongMaterial({ color: 0xffffff }));
    
  //   meshes.push(mesh);
  // }
  // for (let i = 0; i < meshes.length; i++) {
  //     scene.add(meshes[i]);
  //   }
  // // render the scene
  // renderer.render( scene, camera );

