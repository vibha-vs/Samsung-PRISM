import numpy as np
import cv2
import json



def cloud_points_generator(contours,height):
    
    final_contour_list = []
    for contour in contours:   
        contour_points = []
        for point in contour:
            print(point[0][0])
            new_base_point = [point[0][0],point[0][1],0]
            print(new_base_point)
            
            new_top_point = [point[0][0],point[0][1],height]
            print(new_top_point)
            
            contour_points.append(new_base_point)
            contour_points.append(new_top_point)
        
        
        final_contour_list.append(contour_points)
    return final_contour_list


im = cv2.imread("houseplan.png")
img = im.copy()

imgray = cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
ret,thresh = cv2.threshold(imgray,10,255,0)
contours, hierarchy = cv2.findContours(thresh,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

new_contours = []
for contour in contours:
    
    area = cv2.contourArea(contour)
    if area > 50:
        new_contours.append(contour)
        

cv2.drawContours(im,new_contours,-1,(0,0,255),1)

print(new_contours)

ff = cloud_points_generator(new_contours, 5)


# a = {}
# a.update({"data":ff})

# with open(r'D:\dev\projects\Samsung Prism\my_first_list.json', 'w') as f:
#     json.dump(ff[0], fp=f)




# cv2.imshow('rec',img)
# cv2.waitKey(0)
# cv2.destroyAllWindows()


cv2.imshow('image',im)
cv2.waitKey(0)
cv2.destroyAllWindows()